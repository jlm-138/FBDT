%Subfunction: find the set of all discrete points among the possible boundary points from L_index+1 to R_index-1, recursive function
% Input: BoundaryPoints - the value of the attribute at the boundary point;
% L_index - the index value of the leftmost boundary point, which, when equal to 0, indicates data to the left of the first boundary point
% R_index-- The index value of the rightmost boundary point. When it is equal to 1, it indicates the data to the right of the last boundary point.
% Num - indicates the initial number of boundary points (the number of boundary points corresponding to the search for the first dichotomized division point)
% Output: Disc - the final set of dichotomized discrete points
function BinCut(BoundaryPoints,L_index,R_index,X,Label,Num_Initial)

global Disc

if  R_index-L_index>1
    %
    [IndexBestCut,Index_left,Index_right,EntS1,EntS2,EntS,Entropy_min,L1,L2]=Get_best(BoundaryPoints,L_index,R_index,X,Label,Num_Initial);
    Index_left_min=Index_left{IndexBestCut-L_index,1};
    Index_right_min=Index_right{IndexBestCut-L_index,1};
    EntS1_min=EntS1(IndexBestCut-L_index,1);
    EntS2_min=EntS2(IndexBestCut-L_index,1);
    L1_min=L1(IndexBestCut-L_index,1); %
    L2_min=L2(IndexBestCut-L_index,1); %
    N=L1_min+L2_min; %
    
    %
    [flag,MDLP]=MDLP_Accepted(Index_left_min,Index_right_min,EntS1_min,EntS2_min,EntS,Entropy_min,N,Label);
    
    if flag==1 
        Disc=[Disc,BoundaryPoints(IndexBestCut)];
        %
        BinCut(BoundaryPoints,L_index,IndexBestCut,X,Label,Num_Initial);
        BinCut(BoundaryPoints,IndexBestCut,R_index,X,Label,Num_Initial);
%     else
%         if R_index-L_index-1==Num_Initial  %
%             Disc=BoundaryPoints(IndexBestCut);
%         end
    end
end

end






