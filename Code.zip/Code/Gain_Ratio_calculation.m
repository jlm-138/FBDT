 % dataset_label_index is the classification symbol corresponding to dataset, the number of rows is equal to the number of rows of dataset; 
 %label_index is the global label index;
 %dataset_membership corresponds to dataset, each data corresponds to a cell, the number of rows is equal to the number of rows of dataset. is equal to dataset
function [fuzzy_entropy,Gain_Ratio]=Gain_Ratio_calculation(dataset,dataset_membership,label_index,dataset_label_index,every_attribute_fuzzy_amount,membership)

dataset_class_amount=zeros(size(label_index,1),1);

for j=1:size(label_index,1)
    for i=1:size(dataset,1)
        if  isequal(label_index(j,:),dataset_label_index(i,:))
            if isempty(membership)
                dataset_class_amount(j,1)= dataset_class_amount(j,1)+1;
            else
                dataset_class_amount(j,1)=membership(i,:)+dataset_class_amount(j,1);
            end
        end
    end
end
%ID
ID=0;
for i=1:size(label_index,1)
    if dataset_class_amount(i,1)~=0  %Because dataset_class_amount calculates the number of datasets belonging to each class in the label_index containing 0 elements, it is important to determine whether the number of classes in the dataset is 0 elements or not
        ID=-dataset_class_amount(i,1)./sum(dataset_class_amount).*log2(dataset_class_amount(i,1)./sum(dataset_class_amount))+ID;
    end
end

% D(i,j) denotes the sum of the subordination of the jth division of the ith feature
%data_number_support_every_feather number of class points supporting each feature
D=cell(size(dataset,2),1);
for i=1:size(dataset,2)
    D{i,1}=zeros(1,every_attribute_fuzzy_amount(i,1)) ;
end
for i=1:size(dataset,2)
    for j=1:every_attribute_fuzzy_amount(i,1)
        for k=1:size(dataset,1)
            %             if isempty (D{i,1})
            %              D{i,1}(1,j)=dataset_membership{k,1}{i,1}(1,j)
            %             else
            if isempty(membership)
                D{i,1}(1,j)=dataset_membership{k,1}{i,1}(1,j)+ D{i,1}(1,j);
            else
                D{i,1}(1,j)=dataset_membership{k,1}{i,1}(1,j).*membership(k,:)+ D{i,1}(1,j);
                %D{i,1}(1,j)=dataset_membership{k,1}{i,1}(1,j)+ D{i,1}(1,j);
            end
            %             end
        end
    end
end

%D_featuredivision_class(i,j,k) denotes the sum of the affiliations of the data when the class corresponding to the jth division of the ith feature (the number of features is equal to the number of initial data features) is k
D_featuredivision_class=cell(size(dataset,2),1);
for i=1:size(dataset,2)
  D_featuredivision_class{i,1}=zeros(every_attribute_fuzzy_amount(i,1),size(dataset_class_amount,1));
end
for k=1:size(dataset_class_amount,1)
   for i=1:size(dataset,2)
        for j=1:every_attribute_fuzzy_amount(i,1)
             for m=1:size(dataset,1)
                if isequal(label_index(k,:),dataset_label_index(m,:))
                   if isempty(membership)
                      D_featuredivision_class{i,1}(j,k)=dataset_membership{m,1}{i,1}(1,j)+D_featuredivision_class{i,1}(j,k);
                   else
                      D_featuredivision_class{i,1}(j,k)=dataset_membership{m,1}{i,1}(1,j).*membership(m,:)+D_featuredivision_class{i,1}(j,k);     
                   end
                end
            end
        end
    end
end

%I_D denotes the information of the jth division of the ith feature
I_D=cell(size(dataset,2),1);
for i=1:size(dataset,2)
   I_D{i,1}=zeros(1,every_attribute_fuzzy_amount(i,1));
end
for i=1:size(dataset,2)
    for j=1:every_attribute_fuzzy_amount(i,1)
        for k=1:size(dataset_class_amount,1)
            if D_featuredivision_class{i,1}(j,k)~=0 && D{i,1}(1,j)~=0
             I_D{i,1}(1,j)=I_D{i,1}(1,j)-D_featuredivision_class{i,1}(j,k)./D{i,1}(1,j).*log2(D_featuredivision_class{i,1}(j,k)./D{i,1}(1,j));
            end
        end
    end
end
%����ÿ����������������ϢE
 %%�����i���������ܵ���Ϣ
D_total=zeros(size(dataset,2),1);
for i=1:size(dataset,2)
    for j=1:every_attribute_fuzzy_amount(i,1)
        D_total(i,1)=D_total(i,1)+D{i,1}(1,j);
    end
end
E=zeros(size(dataset,2),1);
for i=1:size(dataset,2)
    for j=1:every_attribute_fuzzy_amount(i,1)
        if D_total(i,1)~=0
        E(i,1)=E(i,1)+D{i,1}(1,j).*I_D{i,1}(1,j)./D_total(i,1);
        end
    end
end
% Calculate the information gain for each feature
G=zeros(size(dataset,2),1);
for i=1:size(dataset,2)
  G(i,1)=ID-E(i,1);%ʹ�ñ�׼�������Ϣ������
end
fuzzy_entropy=G;
%%%% information gain rate calculation
split_Information=zeros(size(dataset,2),1) ;
for i=1:size(dataset,2)
    for j=1:every_attribute_fuzzy_amount(i,1)
        if D{i,1}(1,j)~=0
           split_Information(i,1)=-1.* D{i,1}(1,j)./D_total(i,1).*log2(D{i,1}(1,j)./D_total(i,1))+split_Information(i,1);
        end
    end
end
%%%nformation gain rate
Gain_Ratio=zeros(size(dataset,2),1);
for i=1:size(dataset,2)
    if split_Information(i,1)~=0
    Gain_Ratio(i,1)=G(i,1)./split_Information(i,1);
    end
end
 Gain_Ratio;
end