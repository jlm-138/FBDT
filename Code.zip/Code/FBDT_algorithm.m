function node = FBDT_algorithm(data,data_membership,label_index,label,labels,every_attribute_fuzzy_amount,branch,attribute_division,attribute_character_number,size_data,dataset_initial_number,membership,attribute_amount,membership_root,leaf_size,leaf_purity,label_initial)
% input:
%data: the data used for decision tree construction, 
%data_membership: the affiliation of the data, %label_index: the number of class labels for the data,
%label: the class label that corresponds one-to-one with data.
%data_membership: affiliation of the data, 
%data_index: number of class labels for the data, 
%label: class label corresponding to the data (size varies because of the change in size)
%label_index: number of class labels for data, %label: class labels corresponding to data (size varies because of the change in size).
%label: the class label that corresponds to the data (size varies because of data partitioning), %label: the name of the attribute that is used to construct the decision tree.
%labels: the names of the attributes, 
%label_indexevery_attribute_fuzzy_amount: number of fuzzy divisions for each attribute, 
%branch: branch of the decision tree, store the branch name, 
%attribute_division: name of each region in which the attribute is divided,
%size_data: size of the data, %dataset_initialization
%attribute_amount: number of attributes in the data, %membership_root.
%membership_root,leaf_size: the size of the leaf node for the termination condition of the decision tree, %membership_root,leaf_size
%leaf_purity: decision tree termination condition leaf node size, 
%membership_root,%leaf_size: decision tree termination condition leaf node size, 
%label_initial: the initial class label of the data used to construct the decision tree.
%output:
%node(decision tree, struct structure)
%Constructing information storage structures for decision trees
node = struct('value','null','node_label',[],'branch',branch,'children',[],'consequent_distribution',[],'dataset_initial_number',[],'membership',membership,'membership_root',membership_root,'rule_weight_initial',[],'most_class_rate',[],'replace',[]);
%Store node data, record location of data
for k=1:size(dataset_initial_number,1)
    node.dataset_initial_number(1,k)=dataset_initial_number(k,1);
end

if isempty(membership_root)
    
else
    B=zeros(size(label_index,1),1);
    for i=1:size(label_index,1)
        for j=1:size(label,1)
            %  if strcmp(label_index(i,:),label(j,:))
            if isequal(label_index(i,:),label(j,:))
                B(i,1)= B(i,1)+membership_root(j,:);
            end
        end
    end
    P=0;p=0;
    for i=1:size(B,1)
        if B(i,1)>P
            P=B(i,1);
            p=i;
        end
    end
    node_total=0;
    for i=1:size(B,1)
        node_total=B(i,1)+node_total;
    end
    b=max(B);
    node.most_class_rate(1,:)=b./sum(B);
    % if the proportion of values of a class of affiliation reaches the set value, then the name of a class is paid to the leaf node
    %Judge whether the value of the attribute is null or not, if it is null, then generate the leaf node and return it
    if isempty(labels)
        node.value = label_index(p,:);% Hard division
        node.most_class_rate(1,:)=b./sum(B);
        %%%Calculate the resultant belief distribution of leaf nodes
        [consequent_degree_1,econf]= consequent_degree_and_econf(node.membership_root,label_index,node.dataset_initial_number,label_initial);
        node.consequent_distribution(1,:)=consequent_degree_1;
        node.rule_weight_initial( 1,:)=econf;
        return
    end
% Determine leaf node purity
    if B(p,1)./node_total>=leaf_purity
        node.value = label_index(p,:);
        %%%Calculate the resultant belief distribution and initial rule weight for leaf node
        [consequent_degree_1,econf]= consequent_degree_and_econf(node.membership_root,label_index,node.dataset_initial_number,label_initial);
        node.consequent_distribution(1,:)=consequent_degree_1;
        node.rule_weight_initial(1,:)=econf;
        return
    end
    %The sum of the node's affiliations is less than the set value
    if node_total./size_data<=leaf_size%0.10
        node.value = label_index(p,:);
       %%%Calculate the resultant belief distribution and initial rule weight for leaf node
        [consequent_degree_1,econf]= consequent_degree_and_econf(node.membership_root,label_index,node.dataset_initial_number,label_initial);
        node.consequent_distribution(1,:)=consequent_degree_1;
        node.rule_weight_initial( 1,:)=econf;
        return;
    end
end

%Calculation of fuzzy gain ratio
[fuzzy_entropy,Gain_Ratio]=Gain_Ratio_calculation(data,data_membership,label_index,label,every_attribute_fuzzy_amount,membership);
%C4.5---Gain_Ratio  Id3---fuzzy_entropy
F=Gain_Ratio;
a=0;
for i=1:size(F,1)
    if F(i,:)<=0
        a=a+1;
    end
end
%Determine whether the fuzzy gain rate is 0, if it is 0, then generate leaf node return
if size(F,1)==a
    %   node.value= A(p,:);
    if isempty(membership_root)
    else
        B=zeros(size(label_index,1),1);
        for i=1:size(label_index,1)
            for j=1:size(label,1)
                %    if strcmp(label_index(i,:),label(j,:))
                if isequal(label_index(i,:),label(j,:))
                    B(i,1)= B(i,1)+membership_root(j,:);
                end
            end
        end
        P=0;p=0;
        for i=1:size(B,1)
            if B(i,1)>P
                P=B(i,1);
                p=i;
            end
        end
        b=max(B);
        node.most_class_rate(1,:)=b./sum(B);
        node.value = label_index(p,:);
       
        [consequent_degree_1,econf]= consequent_degree_and_econf(node.membership_root,label_index,node.dataset_initial_number,label_initial);
        node.consequent_distribution(1,:)=consequent_degree_1;
        node.rule_weight_initial(1,:)=econf;
    end
    return ;
else
    % Selection of optimal segmentation attributes
    [best_value,best_value_number]=find_best_value(F,labels);
end
%Split data
if size(data,2)==1
    subdata_label=cell(every_attribute_fuzzy_amount,1);
    subdata_initial_number=cell(every_attribute_fuzzy_amount,1);
    subdata_node_membership_for_best_value=cell(every_attribute_fuzzy_amount,1);
    subdata_location_index=cell(every_attribute_fuzzy_amount,1);
    for i=1:every_attribute_fuzzy_amount
        k=0;
        for j=1:size(data,1)
            if iscell(data_membership)
                if data_membership{j,1}{best_value_number,1}(1,i)~=0
                    k=k+1;
                    subdata_initial_number{i,1}(k,:)=dataset_initial_number(j,:);
                    subdata_label{i,1}(k,:)=label(j,:);
                    subdata_node_membership_for_best_value{i,1}(k,1)=data_membership{j,1}{best_value_number,1}(1,i);
                    subdata_location_index{i,1}(k,1)=j;
                end
            end
        end
    end
    subdata=[];
    subdata_membership=[];
else
%     [subdata,subdata_membership,subdata_label,subdata_initial_number,subdata_node_membership_for_best_value,subdata_location_index,error_rate_before_dividion,error_rate_after_dividion,total_number]=split_dataset(best_value_number,data,data_membership,every_attribute_fuzzy_amount,label,dataset_initial_number)
      [subdata,subdata_membership,subdata_label,subdata_initial_number,subdata_node_membership_for_best_value,subdata_location_index]=split_dataset(best_value_number,data,data_membership,every_attribute_fuzzy_amount,label,dataset_initial_number);
end
every_attribute_fuzzy_amount(best_value_number,:)=[];

labels(:,best_value_number)=[];
node.node_label = best_value;
subdata_node_membership_for_best_value_root=cell(size(subdata_node_membership_for_best_value,1),1);
for i=1:size(subdata_node_membership_for_best_value,1)
    if isempty(subdata_location_index{i,1})
        y=1;
    else
        subdata_node_membership_for_best_value_root{i,1}=zeros(size(subdata_node_membership_for_best_value{i,1},1),1);
        for j=1:size(subdata_node_membership_for_best_value{i,1},1)
            if attribute_amount==size(labels,2)+1%根节点membership为空
                subdata_node_membership_for_best_value{i,1}(j,1)=subdata_node_membership_for_best_value{i,1}(j,1);
                subdata_node_membership_for_best_value_root{i,1}(j,1)=subdata_node_membership_for_best_value{i,1}(j,1);
            else
                subdata_node_membership_for_best_value{i,1}(j,1)=subdata_node_membership_for_best_value{i,1}(j,1).*membership(subdata_location_index{i,1}(j,1),1);
                subdata_node_membership_for_best_value_root{i,1}(j,1)=(subdata_node_membership_for_best_value{i,1}(j,1).*membership(subdata_location_index{i,1}(j,1),1))^(1./(attribute_amount-size(labels,2)));
            end
        end
    end
end
%Determine if subdata is empty
if isempty(subdata)
    h=1;
    for i=1:size(subdata_label,1)
        if isempty(subdata_label{i,1})
        else
            membership=subdata_node_membership_for_best_value{i,1};
            membership_root=subdata_node_membership_for_best_value_root{i,1};
            branch=attribute_division{best_value_number,1}(1,(i-1)*attribute_character_number+1:i*attribute_character_number);
            node.children= [node.children FBDT_algorithm(subdata,subdata_membership,label_index,subdata_label{i,1},labels,every_attribute_fuzzy_amount,branch,attribute_division,attribute_character_number,size_data,subdata_initial_number{i,1},membership,attribute_amount,membership_root,leaf_size,leaf_purity,label_initial)];
        end
    end
else
    for i=1:size(subdata,1)
        %Determine if subdata{i,1} is null
        M=0;
        for j=1:size(subdata{i,1},1)
            for k=1:size(subdata{i,1},2)
                if subdata{i,1}(j,k)~=0
                    M=M+1;
                end
            end
        end
        M;
        if M~=0
            membership=subdata_node_membership_for_best_value{i,1};
            membership_root=subdata_node_membership_for_best_value_root{i,1};
            branch=attribute_division{best_value_number,1}(1,(i-1)*attribute_character_number+1:i*attribute_character_number);
            mid_attribute_division=attribute_division;
            mid_attribute_division(best_value_number,:)=[];
            sub_attribute_division=mid_attribute_division;
            node.children = [node.children FBDT_algorithm(subdata{i,1},subdata_membership{i,1},label_index,subdata_label{i,1},labels,every_attribute_fuzzy_amount,branch,sub_attribute_division,attribute_character_number,size_data,subdata_initial_number{i,1},membership,attribute_amount,membership_root,leaf_size,leaf_purity,label_initial)];
        end
    end
end
end