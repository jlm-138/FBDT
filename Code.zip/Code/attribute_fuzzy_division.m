function [data_membership,fuzzy_division_points]=attribute_fuzzy_division(data,label_index,Label)
%%%input:
%data:Attribute information for the dataset,
%label_index:Category Tags collection matrix
%Label:and data one-to-one, with the corresponding label for each data
%%%output:
%data_membership:Membership information for the dataset
%fuzzy_division_points:Fuzzy points selected by discrete points
N1=size(data,1);  
P=size(data,2); 
M=size(label_index,1); 

K=zeros(1,P); 
PointSets=cell(1,P); 
Num_disc=zeros(1,P);
Disc=cell(1,P); 
% tic
for i=1:P
    X=data(:,i);
    a=min(X); 
    b=max(X); 
    Disc{i}=Fayyad_test(X,Label);  
    
    Num_disc(i)=length(Disc{i});  
    if Num_disc(i)==0
        K(i)=0;
    else
        d=zeros(1,Num_disc(i)+1); 
        d(1)=Disc{i}(1)-a;
        d(Num_disc(i)+1)=b-Disc{i}(Num_disc(i));
        for j=2:Num_disc(i)
            d(j)=Disc{i}(j)-Disc{i}(j-1);
        end
        dd=zeros(1,Num_disc(i)); 
        for k=1:Num_disc(i)
          c=[d(k),d(k+1)];
          dd(k)=min(c);
        end
       
        
        PointSets{i}=zeros(1,2*Num_disc(i));
        for j=1:Num_disc(i)
            PointSets{i}(1,2*j-1)=Disc{i}(j)-0.3*dd(j);
            PointSets{i}(1,2*j)=Disc{i}(j)+0.3*dd(j);
        end
        
        K(i)=length(PointSets{i}); 
    end
end


Mu=cell(N1,1);
for j=1:N1
    Mu{j,1}=cell(P,1);
    for i=1:P
        if Num_disc(i)>0    
            Mu{j,1}{i,1}=Membership(data(j,i),K(i),PointSets{i});
%             Mu{j,1}{i,1}(find(Mu{j,1}{i,1}<0.5))=0; 
%             Mu{1,j}{i,1}(find(Mu{1,j}{i,1}>=0.5))=1; 
        end
    end
end
data_membership=Mu;
fuzzy_division_points=PointSets;
end