function [ CombinedBeliefDegree, RemainingBeliefDegree ] = TCR(m_discounting_operation ,s)
%% CCR -- T-norms combination rule
%   BliefMatrix: the decision matrix [attributes'Num, evaluation grades'num]
%   Re_F: the reliability factor
%   s: the parameter of Frank t-norm
%   CombinedBeliefDegree: the overall combined degree of belief
%   RemainingBeliefDegree: the remaining belief degree unassigned to any decision

%   Copyright 2014-2015 Lianmeng Jiao
%   $Version: 1.0 $  $Date: 2014/12/2 $
Class_amount=size(m_discounting_operation{1,1},2);
for i=1:size(m_discounting_operation,2)
    BliefMatrix(i,:)=m_discounting_operation{1,i}(:,1:Class_amount-1);
end
[N,L] = size(BliefMatrix);
if size(m_discounting_operation,1)==1 & sum(BliefMatrix)==1
    CombinedBeliefDegree= BliefMatrix(i,:);
    RemainingBeliefDegree = 1 - sum(CombinedBeliefDegree);
else
    % Step0: Compute the basic belief assignment (bba)
    for i= 1:N
        rbba(i,:) = BliefMatrix(i,:);
        rbba_H(i) = 1 - sum(BliefMatrix(i,:));
    end
    
    % % Step1: Reliability discounting
    % for i= 1:N
    %     rbba(i,:) = Re_F(i)*bba(i,:);
    %     rbba_H(i) = Re_F(i)*bba_H(i) + (1 - Re_F(i));
    % end
    
    % Step2: Calculating w
    for i= 1:N
        w(i,:) = rbba_H(i)./(rbba_H(i) + rbba(i,:));%�����ž���û�в�ȷ����ʱ����ĳһ������Ŷ�Ϊ1��������rbba_H(i)Ϊ0 rbba(i,:)�д���0Ԫ��
    end
   
    if N == 1
        w_tnorm = w(1,:);
    else
        if s==1%dempster��Ϲ���
            for j = 1:L
                w_tnorm(j) = w(1,j)*w(2,j);
                if N > 2
                    for i=3:N
                        w_tnorm(j) = w_tnorm(j)*w(i,j);
                    end
                end
            end
        elseif s==0 %cautious��Ϲ���
            for j = 1:L
                w_tnorm(j) = min(w(1,j),w(2,j));
                if N > 2
                    for i=3:N
                        w_tnorm(j) =min( w_tnorm(j),w(i,j));
                    end
                end
            end
        else %�������Ƿ�������Ϲ���
            for j = 1:L
                %         w_tnorm(j) = log(1+(s(j)^w(1,j)-1)*(s(j)^w(2,j)-1)/(s(j)-1))/log(s(j));
                w_tnorm(j) = log(1+(s^w(1,j)-1)*(s^w(2,j)-1)/(s-1))/log(s);
                if N > 2
                    for i=3:N
                        %                 w_tnorm(j) = log(1+(s(j)^w_tnorm(j)-1)*(s(j)^w(i,j)-1)/(s(j)-1))/log(s(j));
                        w_tnorm(j) = log(1+(s^w_tnorm(j)-1)*(s^w(i,j)-1)/(s-1))/log(s);
                    end
                end
            end
        end   
    end
    
    % Step3: Combination
    for i= 1:L
        CombinedBeliefDegree(i) = 1;
        for j= 1:L
            if j == i
                CombinedBeliefDegree(i) = CombinedBeliefDegree(i)*(1-w_tnorm(j));
            else
                CombinedBeliefDegree(i) = CombinedBeliefDegree(i)*w_tnorm(j);
            end
        end
    end
    RemainingBeliefDegree = prod(w_tnorm);
    
    % Step4: Normalization
    CombinedBeliefDegree = CombinedBeliefDegree/(sum(CombinedBeliefDegree)+RemainingBeliefDegree);
    RemainingBeliefDegree = 1 - sum(CombinedBeliefDegree);
end


end

