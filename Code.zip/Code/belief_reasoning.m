function reasoning_result=belief_reasoning(association_degree_initial,consequent_degree,test_data,rule_base,fuzzy_division_points,data_max_value,data_min_value,s)
if isempty(association_degree_initial)
    distance=zeros(size(rule_base,1),1);
    for i=1:size(rule_base,1)
        distance(i,1) = distance_between_rule_and_instance(test_data,rule_base(i,:),fuzzy_division_points,data_max_value,data_min_value);
    end
    [distance,index]=sort(distance,1,'ascend');
    reasoning=zeros(size(consequent_degree,2)+1,1);
    for i=1:size(consequent_degree,2)+1
        for j=1:5%
            if i<size(consequent_degree,2)+1
             reasoning(1,i)=consequent_degree(index(j,1),i)./5+reasoning(1,i);
            else
             reasoning(1,i)=(1-sum(consequent_degree(index(j,1),:)))./5+reasoning(1,i);
            end
        end
    end
    reasoning_new=reasoning./sum(reasoning);
else
[association_degree,location]=sort(association_degree_initial,2,'DESCEND');
p=0;
% A=[]
for i=1:size(association_degree,2)
    if association_degree(1,i)~=0
% if association_degree(1,i)>0.1
     p=p+1;
%      A(1,p)=i
    end
end
if  p>5
    P=5;
else
    P=p;
end
m_discounting_operation=cell(1,P);
    for j=1:size(m_discounting_operation,2)
       consequent_degree_entire=1;
        for k=1:size(consequent_degree,2)+1
            if k<=size(consequent_degree,2)
            m_discounting_operation{1,j}(1,k)=association_degree(1,j).*consequent_degree(location(1,j),k);
            consequent_degree_entire=consequent_degree_entire - consequent_degree(location(1,j),k);
            else
            m_discounting_operation{1,j}(1,k)=association_degree(1,j).*consequent_degree_entire + 1 - association_degree(1,j);
            end
        end
    end 

if isempty(m_discounting_operation)
    distance=zeros(size(rule_base,1),1);
    for i=1:size(rule_base,1)
        distance(i,1) = distance_between_rule_and_instance(test_data,rule_base(i,:),fuzzy_division_points,data_max_value,data_min_value);
    end
    [distance,index]=sort(distance,1,'ascend');
    reasoning=zeros(1,size(consequent_degree,2)+1);
    for i=1:size(consequent_degree,2)+1
        if size(rule_base,1)<5
            for j=1:size(rule_base,1)
                if i<size(consequent_degree,2)+1
                    reasoning(1,i)=consequent_degree(index(j,1),i)./size(rule_base,1)+reasoning(1,i);
                else
                    reasoning(1,i)=(1-sum(consequent_degree(index(j,1),:)))./size(rule_base,1)+reasoning(1,i);
                end
            end
        else
            for j=1:5%
                if i<size(consequent_degree,2)+1
                    reasoning(1,i)=consequent_degree(index(j,1),i)./5+reasoning(1,i);
                else
                    reasoning(1,i)=(1-sum(consequent_degree(index(j,1),:)))./5+reasoning(1,i);
                end
            end
        end
    end
    reasoning_new=reasoning./sum(reasoning);
else
    [ CombinedBeliefDegree, RemainingBeliefDegree ] = TCR(m_discounting_operation ,s);
    reasoning_new=[ CombinedBeliefDegree, RemainingBeliefDegree ];
end


end
 reasoning_result=reasoning_new;
end