%%%Calculation of outcome confidence and evidence confidence for decision tree leaf nodes
function [consequent_degree,econf]= consequent_degree_and_econf(total_every_data_membership_for_rule,label_index,node_dataset_initial_number,label)
   sup_every_class=zeros(size(label_index,1),1);
   sup_every_class_number=zeros(size(label_index,1),1);
   dataset_divided_total =ones(size(label_index,1),1);
   for i=1:size(node_dataset_initial_number,2)
     for k=1:size(label_index,1)
%              if strcmp(label_index(k,:),label(node.dataset_initial_number(1,i),:))
        if isequal(label_index(k,:),label(node_dataset_initial_number(1,i),:))
           dataset_divided_total(k,1)=dataset_divided_total(k,1).*(1-total_every_data_membership_for_rule(i,:));
           sup_every_class(k,1)=sup_every_class(k,1)+total_every_data_membership_for_rule(i,:)./size(node_dataset_initial_number,2);
           sup_every_class_number(k,1)=sup_every_class_number(k,1)+1;
            break
        end
     end
   end
   sup_every_class_total=sum(sup_every_class);
   
   dataset_divided_total_every_class =zeros(size(label_index,1),1);
   for k=1:size(label_index,1)
      dataset_divided_total_every_class(k,1)=1-dataset_divided_total(k,1);
      gama_every_class(k,1)=sup_every_class(k,1)./sup_every_class_total;
   end
   %
   dataset_conflict=ones(size(label_index,1),1);
   for i=1:size(label_index,1)
       for j=1:size(label_index,1)
           if i~=j
            dataset_conflict(i,1)=dataset_conflict(i,1).*(1-gama_every_class(j,1)+gama_every_class(j,1).*dataset_divided_total(j,1));
           end    
       end
   end
   consequent=zeros(1,size(label_index,1)+1);
   for k=1:size(label_index,1)
           if k==1
      consequent(1,k)=gama_every_class(k,1).* dataset_divided_total_every_class(k,1).* dataset_conflict(k,1);
      consequent(1,size(label_index,1)+1)=1-gama_every_class(k,1)+gama_every_class(k,1).*dataset_divided_total(k,1);
           else
      consequent(1,k)=gama_every_class(k,1).* dataset_divided_total_every_class(k,1).* dataset_conflict(k,1) ;       
      consequent(1,size(label_index,1)+1)= consequent(1,size(label_index,1)+1).*(1-gama_every_class(k,1)+gama_every_class(k,1).*dataset_divided_total(k,1)) ; 
           end
   end
   consequent_total=sum(consequent,2);
   consequent_degree=zeros(1,size(label_index,1));
    for i=1:size(label_index,1)
      consequent_degree(1,i)=consequent(1,i)./consequent_total;
    end
    %
   consequent_degree_total=sum(consequent_degree,2);
   theta_every_class=zeros(1,size(label_index,1));
   for i=1:size(label_index,1)
     theta_every_class(1,i)=consequent_degree(1,i)+ (1-consequent_degree_total)./size(label_index,1);
   end
   esup=0;
   for i=1:size(label_index,1)
     esup=theta_every_class(1,i).*sup_every_class(i,1)+esup;
   end
   econf=esup./sup_every_class_total;
end