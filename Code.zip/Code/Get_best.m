% subfunction: find the division point with the lowest entropy among the possible boundary points from L_index+1 to R_index-1

function [IndexBestCut,Index_left,Index_right,EntS1,EntS2,EntS,Entropy_min,L1,L2]=Get_best(BoundaryPoints,L_index,R_index,X,Label,Num_Initial)

Num_boundary=R_index-L_index-1;
Index_left=cell(Num_boundary,1); 
Index_right=cell(Num_boundary,1); 
EntS1=zeros(Num_boundary,1); 
EntS2=zeros(Num_boundary,1);
Entropy=zeros(Num_boundary,1); 
L1=zeros(Num_boundary,1);
L2=zeros(Num_boundary,1);

for i=L_index+1:R_index-1
    
    if L_index<1
        Index_left{i-L_index,1}=find(X<BoundaryPoints(i));
    else
        Index_left{i-L_index,1}=find(BoundaryPoints(L_index)<X & X<BoundaryPoints(i));
    end
    
    if R_index>Num_Initial
        Index_right{i-L_index,1}=find(X>BoundaryPoints(i));
    else
        Index_right{i-L_index,1}=find(BoundaryPoints(i)<X & X<BoundaryPoints(R_index));
    end
    
    %Find the entropy value with the ith boundary point as the cutting point
    EntS1(i-L_index,1)=Entropy_interval(Index_left{i-L_index,1},Label); 
    EntS2(i-L_index,1)=Entropy_interval(Index_right{i-L_index,1},Label); 
    
    
    
    %In the following, the entropy value derived from the ith boundary point is determined to find the gain value
    L1(i-L_index,1)=length(Index_left{i-L_index,1}); %
    L2(i-L_index,1)=length(Index_right{i-L_index,1}); %
    N=L1(i-L_index,1)+L2(i-L_index,1);
    Entropy(i-L_index,1)=L1(i-L_index,1)*EntS1(i-L_index,1)/N+L2(i-L_index,1)*EntS2(i-L_index,1)/N;
end
Index_all=[Index_left{1,1};Index_right{1,1}];%
EntS=Entropy_interval(Index_all,Label); %
% EntS=Entropy_interval_pignistic(Index_all,Label_Mass); 
[Entropy_min,Index]=min(Entropy);
IndexBestCut = Index + L_index;  
end

