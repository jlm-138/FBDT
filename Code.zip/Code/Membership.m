%2020.7.1/12.23
%Subfunction: find the affiliation function based on the obtained discrete points
%There are three different cases: no discrete points, one discrete point, more than two discrete points
% Combines triangulation and trapezoidal division, fuzzy division is based on 0.5-cuts
% Input: x-an attribute value (number) in the data;
% Partition_points - number of partition points excluding left and right endpoints
% K - number of points included in the set of Partition_points
% Output: u - row vector storing the values of affiliation assigned to each interval, the resulting affiliation interval does not take into account 0.5cut
%2020.7.20 - modification of the program
function u=Membership(x,K,Partition_points)

n=K/2;  
u=zeros(1,n+1); 

%
if x<=Partition_points(1)
    u(1)=1;
else if x>Partition_points(K)
        u(n+1)=1;
    else
        %
        if n==1  %
           u(1)=(Partition_points(2)-x)/(Partition_points(2)-Partition_points(1)); 
           u(2)=(x-Partition_points(1))/(Partition_points(2)-Partition_points(1));  
        else
            for j=2:n
                if x>Partition_points(2*j-3) & x<=Partition_points(2*j-2) %
                    u(j-1)=(Partition_points(2*j-2)-x)/(Partition_points(2*j-2)-Partition_points(2*j-3));
                    u(j)=(x-Partition_points(2*j-3))/(Partition_points(2*j-2)-Partition_points(2*j-3));
                else if x>Partition_points(2*j-1) & x<=Partition_points(2*j)  %
                        u(j)=(Partition_points(2*j)-x)/(Partition_points(2*j)-Partition_points(2*j-1));
                        u(j+1)=(x-Partition_points(2*j-1))/(Partition_points(2*j)-Partition_points(2*j-1));
                    else if x>Partition_points(2*j-2) & x<=Partition_points(2*j-1)  %
                            u(j)=1;
                        end
                    end
                end
            end
        end
    end
end

















