function [bestChromosome,best_rule_base,best_consequent,best_rule_weight,best_length_of_rule]=genetic_algorithm_rule_selection(association_degree,rule_base,Rate,data,data_label,label_index,consequent,rule_weight,fuzzy_division_points,data_max_value,data_min_value,length_of_rule,s,ro)
%Rule selection using genetic algorithms
%input��
%     %Rate:Initial chromosome length as a proportion of rule base size
%     data:Training data attribute information
%     numofchromosome:Number of chromosomes, i.e. iterative population size
%     iterationNum:The total number of iterations, the iteration is terminated when the number of iterations is reached

%output��
%     bestChromosome:optimal chromosome
%     best_rule_base:Rule base for optimal chromosome generation
%     best_consequent:Conclusion section of the corresponding rule for the optimal chromosome rule base


N=size(rule_base,1);%�����Ĺ�ģ
len=ceil(N*Rate);%��ʼȾɫ�峤��

if floor(nchoosek(N,len))>=30
    NP=30;
else
    %     NP=floor(nchoosek(N,len))
    NP=20;
end
G=100;% Maximum number of generations
L=N;% binary bit string length
Pc=0.6;% crossover rate
Pm=0.1;% variation rate
%%%%%Randomized generation of initial populations
f=rand(NP,N);
f=round(f);%
f(NP,:)=ones(1,N);
F=[];

fit=zeros(NP,1);
acc=zeros(NP,1);
inp=zeros(NP,1);
for i=1:NP
    [fit(i,1),acc(i,1),inp(i,1)]=func_fitness(f(i,:),data,data_label,label_index,rule_base,consequent,fuzzy_division_points,data_max_value,data_min_value,length_of_rule,ro,s,association_degree,rule_weight);
end
[mf,mn]=max(fit);
Best=f(mn,:);% storage of optimal chromosomes
Best_fit=fit(mn,:);
Best_acc=acc(mn,:);
Best_inp=inp(mn,:);
%%%%%genetic algorithm cycle
for k=1:G
    select_number=[];

      %%%%%Rule selection by tournament method
        for p=1:NP
            q=randperm(NP,3); 
            Q=[fit(q(1));fit(q(2));fit(q(3))];
            [Y,U]=max(Q);
            nf(p,:) = f(q(U),:);
            nfit(p,:)=fit(q(U),1);
            nacc(p,:)=acc(q(U),1);
            ninp(p,:)=inp(q(U),1);
        end
        %%%%%Uniform crossover operation
        cross_num=ceil(NP*Pc);
        for j=1:cross_num
            z=randperm(NP,2);
            select_number=[z,select_number];
            w=rand(N,1);
            for i=1:N
                if w(i)<=Pc
                    temp=nf(z(1),i);
                    nf(z(1),i)=nf(z(2),i);
                    nf(z(2),i)=temp;
                end
            end
        end
    %%%%%variant operation
    mutation_num=ceil(NP*Pm);
    for j=1:mutation_num
        h=randi([1,NP],1,1);
        select_number=[h,select_number];
        g=rand(N,1);
        for i=1:N
            if g(i)<=Pm
                if nf(h(1),i)==0
                    nf(h(1),i)=1;
                else
                    nf(h(1),i)=0;
                end
            end
        end
    end
    select_number=unique(select_number);
    for i=1:size(select_number,2)
        [nfit(select_number(i),1),nacc(select_number(i),1),ninp(select_number(i),1)]=func_fitness(nf(select_number(i),:),data,data_label,label_index,rule_base,consequent,fuzzy_division_points,data_max_value,data_min_value,length_of_rule,ro,s,association_degree,rule_weight);
    end
    f=nf;
    fit=nfit;
    acc=nacc;
    inp=ninp;
    maxfit=max(fit);
    rr=find(fit==maxfit);
    %Compare the optimal individual of the new iteration with the optimal individual of the previous iteration, if the new iteration is optimal, then change the optimal generation, otherwise replace the worst generation of this iteration with the optimal generation
    if Best_fit < fit(rr(1,1),:)
        Best=f(rr(1,1),:);
        Best_fit=fit(rr(1,1),:);
        Best_acc=acc(rr(1,1),:);
        Best_inp=inp(rr(1,1),:);
    else
        minfit=min(fit);
        rc=find(fit==minfit);
        f(rc(1,1),:)=Best;
        fit(rc(1,1),:)=Best_fit;
        acc(rc(1,1),:)=Best_acc;
        inp(rc(1,1),:)= Best_inp;
    end
    if k==49
        y=1
    end
    if k==25
        y=1
    end
end
bestChromosome=Best;
best_rule_base={};
best_consequent=[];
best_rule_weight=[];
best_length_of_rule=[];
for j=1:size(rule_base,1)
    if bestChromosome(j)==1
        best_rule_base=[rule_base(j,:);best_rule_base];
        best_consequent=[consequent(j,:);best_consequent];
        best_rule_weight=[rule_weight(j,:);best_rule_weight];
        best_length_of_rule=[length_of_rule(j,:);best_length_of_rule];
    end
end

if size(best_length_of_rule,1)<size(best_consequent,2)
    q=1;
end
end