%%%%%适应度函数
function [fitness,accuracy,interpretability]=func_fitness(f,data,data_label,label_index,rule_base,consequent,fuzzy_division_points,data_max_value,data_min_value,length_of_rule,ro,s,association_degree,rule_weight)
a={};
b=[];
c=[];
d=[];
e=[];
for j=1:size(rule_base,1)
    if f(j)==1
        a=[rule_base(j,:);a];
        b=[consequent(j,:);b];
        c=[rule_weight(j,:);c];
        d=[length_of_rule(j,:);d];
        e=[association_degree(:,j),e];
    end
end
if isempty(d)
    accuracy=0;
    interpretability=0;
%     fitness=100
     fitness=0;
else
    test_accuracy_rate=classification_accuracy_rate(e,label_index,data,fuzzy_division_points,data_label,data_max_value,data_min_value,a,b,s);
    accuracy=test_accuracy_rate;
     interpretability=c'*d/(rule_weight'*length_of_rule)
     %fitness=ro*(1-accuracy)+(1-ro)*interpretability
     fitness=ro*accuracy+(1-ro)*(1-interpretability);

end
end