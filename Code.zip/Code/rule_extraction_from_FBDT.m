
function [nodeVec,nodeSpec,current_count, rootnode_number,rule_base,depth,consequent_degree,rule_weight_initial,length_of_rule] = rule_extraction_from_FBDT(node,current_count,last_node,nodeVec,nodeSpec,rootnode_number,rule_base,depth,consequent_degree,number_of_data,label_index,label,rule_weight_initial,length_of_rule)%ɾ������data_initiial_number������
global depth
%struct�ṹ���node.valueΪһ��cell
if isempty(nodeVec)
    depth=0
end
rule_number=rootnode_number+1;
if iscell(node.value)
    if strcmp(node.value,'null')
        nodeSpec = [nodeSpec node.node_label];
        current_count = current_count + 1;
        current_node = current_count;
        if strcmp(node.branch,'null')
        else
            rule_base{ rule_number,depth}=node.branch;
        end
    else
        nodeSpec = [nodeSpec node.value];
        current_count = current_count + 1;
        current_node = current_count;
        rootnode_number=rootnode_number+1;
        if strcmp(node.branch,'null')
        else
            rule_base{ rule_number,depth}=node.branch;
        end
        if rule_number~=1
            if isequal(rule_base{ rule_number,1},'')
                for i=1:depth-1
                    if isequal(rule_base{ rule_number,i},'')
                        rule_base{ rule_number,i}=rule_base{ rule_number-1,i};
                    end
                end
            end
        end
        
        length_of_rule(rule_number,1)=depth;
        consequent_degree( rule_number,:)=node.consequent_distribution;
        rule_weight_initial( rule_number,:)=node.rule_weight_initial;
        depth=depth-1;
        return;
    end
else
    if node.value == 'null'
        nodeSpec = [nodeSpec node.node_label];
        if strcmp(node.branch,'null')
        else
            rule_base{ rule_number,depth}=node.branch;
        end
        current_count = current_count + 1;
        current_node = current_count;
    else
        nodeSpec = [nodeSpec node.value];
        current_count = current_count + 1;
        current_node = current_count;
        rootnode_number=rootnode_number+1;
        if strcmp(node.branch,'null')
        else
            rule_base{ rule_number,depth}=node.branch;
        end
        if rule_number~=1
            if isequal(rule_base{ rule_number,1},'')
                for i=1:depth-1
                    if isequal(rule_base{ rule_number,i},'')
                        rule_base{ rule_number,i}=rule_base{ rule_number-1,i};
                    end
                end
            end
        end
        length_of_rule(rule_number,1)=depth;
        consequent_degree( rule_number,:)=node.consequent_distribution;
        rule_weight_initial( rule_number,:)=node.rule_weight_initial;
        depth=depth-1;
        return;
    end
end
for next_node = node.children
    f_number=str2num(next_node.branch(1,2:3));
    if ismember(f_number,nodeVec)
        m=find(nodeVec==f_number);
        depth=m-1;
        b=size(nodeVec,1);
        if m~=size(nodeVec,1)
            nodeVec(m+1:size(nodeVec,1),:)=[];
        end
    end
    if strcmp(next_node .branch,'null')
    else
       nodeVec=[nodeVec; str2num(next_node.branch(1,2:3))];
       nodeVec=unique(nodeVec,'stable');
    end
    depth=depth+1;
    [nodeVec,nodeSpec,current_count,rootnode_number,rule_base,depth,consequent_degree,rule_weight_initial,length_of_rule] = rule_extraction_from_FBDT(next_node,current_count,current_node,nodeVec,nodeSpec,rootnode_number,rule_base,depth,consequent_degree,number_of_data,label_index,label,rule_weight_initial,length_of_rule);
end

end

