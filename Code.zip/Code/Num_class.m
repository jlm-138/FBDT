%Subfunction: determine the number of soft-labeled categories for samples under certain index positions
%Input: Index-column vector representing the position index; Label-the set of category labels for all training samples 

function k=Num_class(Index,Label)

L=length(Index); 
k=1; 
for i=2:L
    flag=1;
    for j=1:i-1
        if isequal(Label(Index(i)),Label(Index(j)))==1
            flag=0;
            break
        end
    end
    if flag==1
        k=k+1;
    end
end

