function  test_accuracy_rate=classification_accuracy_rate(association_degree,label_index,test_data,fuzzy_division_points,test_label,data_max_value,data_min_value,rule_base,consequent_degree,s)
%Belief inference from test data
data_classification=belief_rule_reasoning(test_data,consequent_degree,rule_base,fuzzy_division_points,data_max_value,data_min_value,s,association_degree) ;                        
%Calculating test data labels                        

test_label_consequent=cell(size(data_classification,1),1);
for i=1:size(data_classification,1)
    A=0;
    a=0;
    for j=1:size(data_classification,2)-1
        if data_classification(i,j)>A    
        A=data_classification(i,j);
        a=j;
        end
    end
    if a==0
    test_label_consequent{i,1}(1,1)=-1;
    else
    test_label_consequent{i,1}=label_index(a,:) ;            % label_index{a,:}
    end
end
%%%Calculate the accuracy of test classification results

wrong_classfication_result=[];
accurate_number=0;
wrong=0;
for i=1:size(test_label,1)
%     if strcmp(test_label(i,:),test_label_consequent{i,1})
    if isequal(test_label(i,:),test_label_consequent{i,1})
        accurate_number=accurate_number+1;
    else
        wrong=wrong+1;
        wrong_classfication_result(wrong,1)=test_label(i,:);
        wrong_classfication_result(wrong,2)=test_label_consequent{i,1};
    end
end
test_accuracy_rate=zeros(1,1);
test_consequent=zeros(size(data_classification,1),size(data_classification,2));
accuracy_rate=accurate_number./size(test_data,1);
test_consequent=data_classification;
test_accuracy_rate(1,1)=accuracy_rate;
end