%When activation is 0, calculate the distance of the instance from each rule
%distance
function distance_total = distance_between_rule_and_instance(test_data,rule,fuzzy_division_points,data_max_value,data_min_value)%fuzzy_division_points���Ƿָ�㣬�Ƿָ��ѡȡģ������֮��ĵ�
distance=zeros(size(rule,2),1);
for i=1:size(rule,2)
    if isempty(rule{1,i})==0
       a=str2num(rule{1,i}(1,2:3));%
       b=str2num(rule{1,i}(1,4:5));%
       c=size(fuzzy_division_points{1,a},2)./2; %
       d=fuzzy_division_points{1,a};
       if b==1
            distance(a)=(test_data(1,a)-(data_min_value(1,a)./2+d(1,1)./4+d(1,2)./4))^2./((data_min_value(1,i)-d(1,1)./2-d(1,2)./2)^2);
       else
           if b == c+1
            distance(a)=(test_data(1,a)-(data_max_value(1,i)./2+d(1,2*c)./4+d(1,2*c-1)./4))^2./((data_max_value(1,i)-d(1,2*c)./2-d(1,2*c-1)./2)^2);
           else
            distance(a)=(test_data(1,a)-(d(1,2*c)+d(1,2*c-1)+d(1,2*c-2)+d(1,2*c-3))./4)^2./((d(1,2*c)+d(1,2*c-1)-d(1,2*c-2)-d(1,2*c-3))^2./4);
           end
       end
    end
end
 distance_total=sum(distance);
end