%Subfunctions: Find the entropy value for the sample data at a specific location based on the sequence of attribute values (column vectors) and the soft labels (column cytosolic elements) corresponding to the samples under each attribute value
%Input: Index - column vector, what is being asked for is the dataset corresponding to which positions? Label - the label of the corresponding position is stored.
function EntS=Entropy_interval(Index,Label)%

I=length(Index);
Class_Set=unique(Label(Index));
Num=length(Class_Set); %

Prob=zeros(Num,1); %
for i=1:I  %
    for j=1:Num
        if Label(Index(i))==Class_Set(j)
           Prob(j)=Prob(j)+1;
        end
    end
end
Prob=Prob/I; 

%
Vector=Prob.*log2(Prob);
EntS=-sum(Vector);
end











