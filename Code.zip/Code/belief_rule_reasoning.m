function data_classification=belief_rule_reasoning(test_data,consequent_degree,rule_base,fuzzy_division_points,data_max_value,data_min_value,s,association_degree)

for i=1:size(association_degree,1)
    %    reasoning_result(i,:)=belief_reasoning_rule_selection(association_degree(i,:),consequent_degree)%?????belief_reasoning_rule_selection
    reasoning_result(i,:)=belief_reasoning(association_degree(i,:),consequent_degree,test_data,rule_base,fuzzy_division_points,data_max_value,data_min_value,s);
end
   data_classification=reasoning_result;
end
 
 