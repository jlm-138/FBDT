function assocition_degree_1=association_degree_calculation(test_data,rule_weight,rule_base,attribute_division_initial,every_attribute_fuzzy_amount,fuzzy_division_points,membership)
attribute_character_number=5;
m=max(every_attribute_fuzzy_amount);
attribute_division_cell=cell(size(every_attribute_fuzzy_amount,1),m);
for i=1:size(every_attribute_fuzzy_amount,1)
    for j=1:every_attribute_fuzzy_amount(i,1)
        attribute_division_cell{i,j}=attribute_division_initial{i,1}(1,(j-1).*attribute_character_number+1:j.*attribute_character_number);
    end
end
if isempty(membership)
    data_membership=cell(size(test_data,1),1);
    for j=1:size(test_data,1)
        data_membership{j,1}=cell(size(test_data,2),1);
        for i=1:size(test_data,2)
            if every_attribute_fuzzy_amount(i,1)>0  %
                data_membership{j,1}{i,1}=Membership(test_data(j,i),(every_attribute_fuzzy_amount(i,1)-1).*2,fuzzy_division_points{i});
            end
        end
    end
else
    data_membership=membership;
end

feature_weight=1;
matching_degree=zeros(size(test_data,1),size(rule_base,1));
% for i=1:size(rule_base,1)
%      matching_degree(:,i)=ones(size(test_data,1),1)
% end
for i=1:size(data_membership,1)
    for j=1:size(rule_base,1)
        for k=1:size(rule_base,2)%
            if ~isempty(rule_base{j,k})
                m=str2num(rule_base{j,k}(1,2:3));
                n=str2num(rule_base{j,k}(1,4:5));
                if k==1
                    matching_degree(i,j)=data_membership{i,1}{m,1}(1,n)^feature_weight;
                else
                    matching_degree(i,j)=data_membership{i,1}{m,1}(1,n)^feature_weight.*matching_degree(i,j);
                end
            end
            if k==size(rule_base,2)
                matching_degree(i,j)= matching_degree(i,j)^(1./size(attribute_division_cell,1)).*rule_weight(j,1);% ��ѭ������ʱ��matching_degree��Ϊassociation_degree
            end
        end
    end
end
assocition_degree_1=matching_degree;

end