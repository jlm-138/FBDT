%% 
%%Finding the Optimal Segmentation Property
function [best_value,best_value_number]=find_best_value(fuzzy_entropy,dataset_attribute)%attribute_datasetΪdataset���������Ƶľ���
% function best_value_number=find_best_value(fuzzy_entropy)
p=0;
for i=1:size(fuzzy_entropy,1)
   if p<fuzzy_entropy(i,1)
       p=fuzzy_entropy(i,1);
       best_value_number=i;
   end
end
best_value=dataset_attribute(:,best_value_number);
end
