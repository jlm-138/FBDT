% Subfunction: determine if the resulting optimal division point is accepted or not
% accept-flag=1;not accept-flag=0

function [flag,MDLP]=MDLP_Accepted(Index_left_min,Index_right_min,EntS1_min,EntS2_min,EntS,Entropy_min,N,Label)

flag=0; 

% counts the number of sample categories on the left and right sides of the boundary point corresponding to the point at the minimum entropy value
Num1=Num_class(Index_left_min,Label); %left
Num2=Num_class(Index_right_min,Label); %right
Num=Num_class([Index_left_min; Index_right_min],Label); %all 

D_value=log2(3^Num-2)-(Num*EntS-Num1*EntS1_min-Num2*EntS2_min);

%
Gain=EntS-Entropy_min;
MDLP=Gain-(log2(N-1)+D_value)/N;
if MDLP>0
    flag=1;
end

end

