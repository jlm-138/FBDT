function [subdata,subdata_membership,subdata_label,subdata_initial_number,subdata_node_membership_for_best_value,subdata_location_index]=split_dataset(best_value_number,dataset,dataset_membership,every_attribute_fuzzy_amount,label,dataset_initial_number)
subdata=cell(every_attribute_fuzzy_amount(best_value_number,1),1);
subdata_initial_number=cell(every_attribute_fuzzy_amount(best_value_number,1),1);
subdata_membership=cell(every_attribute_fuzzy_amount(best_value_number,1),1);
subdata_label=cell(every_attribute_fuzzy_amount(best_value_number,1),1);
subdata_node_membership_for_best_value=cell(every_attribute_fuzzy_amount(best_value_number,1),1);
subdata_location_index=cell(every_attribute_fuzzy_amount(best_value_number,1),1);
for i=1:every_attribute_fuzzy_amount(best_value_number,1)
    k=0;
    for j=1:size(dataset,1)
        if iscell(dataset_membership)
            if dataset_membership{j,1}{best_value_number,1}(1,i)~=0
                k=k+1;
                subdata{i,1}(k,:)= dataset(j,:);
                subdata_initial_number{i,1}(k,:)=dataset_initial_number(j,:);
                subdata_membership{i,1}{k,1}=dataset_membership{j,1};
                subdata_label{i,1}(k,:)=label(j,:);
                subdata_node_membership_for_best_value{i,1}(k,1)=dataset_membership{j,1}{best_value_number,1}(1,i);
                subdata_location_index{i,1}(k,1)=j;
            end
        end
    end
end

if isempty(subdata)
else
    for i=1:every_attribute_fuzzy_amount(best_value_number,1)
        if isempty(subdata_membership{i,1})
        else
            for k=1:size(subdata_membership{i,1},1)
                subdata_membership{i,1}{k,1}(best_value_number,:)=[];
            end
        end
        if isempty(subdata{i,1})
        else
            subdata{i,1}(:,best_value_number)=[];
        end
    end
end
end