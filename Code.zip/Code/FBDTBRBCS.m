function [rule_length_average,rule_base_size,test_accuracy_rate]=FBDTBRBCS(data_initial,label_initial,test_data,test_label,attribute_character_number,attribute_division_initial,labels,leaf_size,leaf_purity,label_index,ro)
tic
%%the main function of fuzzy belief decision tree-based classification
%%method
%%%input�?
%data_initial:Attribute information of the training dataset
%label_initial:Training dataset labels
%test_data:Test dataset attribute information
%test_label:Test Data Set Labeling
%attribute_character_number:Indicates the number of characters used in each delimited area for each attribute,experimentally set to 4
%attribute_division_initial:A matrix of type char, storing information about the division characters of all attributes that may be present
%labels:A matrix of cell types, storing all possible attributes
%leaf_size:Termination conditions for leaf node sizes in decision trees
%leaf_purity:Termination conditions for purity of leaf nodes of a decision tree
%label_index:A collection of labeling categories for the dataset
%ro:Interpretability and accuracy balancing factor
%%%output:
%rule_length_average:Average length of generated rule base rules
%rule_base_size:Number of generated rule base rules
%test_accuracy_rate:Correctness of the test set
data=data_initial;
label=label_initial;
%获取data每列的极�?
data_max_value=max(data);
data_min_value=min(data);
%dataset_initial_number:Initial location of stored data
for i=1:size(data,1)
dataset_initial_number(i,1)=i;
end
consequent_distribution=[];
%Delineation of data cut points and calculation of the degree of affiliation
[data_membership,fuzzy_division_points]=attribute_fuzzy_division(data,label_index,label);%fuzzy_division_points----It's not the split point, it's the point after the split point selects the fuzzy interval.
every_attribute_fuzzy_amount=[];
for i=1:size(data_membership{1,1},1)
    every_attribute_fuzzy_amount(i,1)=size(data_membership{1,1}{i,1},2);
end 
%Delete attribute information in the dataset without fuzzy delineation points
t=0;
for i=1:size(every_attribute_fuzzy_amount,1)
    if every_attribute_fuzzy_amount(i,1)==0
        test_data(:,i-t)=[];
        data(:,i-t)=[];
        labels(:,i-t)=[];
        data_initial(:,i-t)=[];
        for k=1:size(data_membership,1)
          data_membership{k,1}(i-t,:)=[];
        end
        fuzzy_division_points(:,i-t)=[];
        t=t+1;
    end
end
every_attribute_fuzzy_amount(all(every_attribute_fuzzy_amount==0,2),:)=[];
%Set the symbol by which the property divides each region, e.g. 'f011'
attribute_division=cell(size(data,2),1);
for i=1:size(data_membership{1,1},1)
    attribute_division{i,1}=attribute_division_initial(i,1:attribute_character_number.*every_attribute_fuzzy_amount(i,1));
end 
size_data=size(data,1);
attribute_amount=size(data,2);
%Constructing a decision tree
rootNode=FBDT_algorithm(data,data_membership,label_index,label,labels,every_attribute_fuzzy_amount,'null',attribute_division,attribute_character_number,size_data,dataset_initial_number,[],attribute_amount,[],leaf_size,leaf_purity,label);
 node_final=rootNode;
 test_data_tree=data_initial;
 test_label_tree=label_initial;
%rule extraction
nodeVec = [];
nodeSpec = [];
edgeSpec = [];
rule_base={};  
consequent_degree=[];
length_of_rule=[];
number_of_data=size(data,1);
rule_weight_initial=[];
depth=0;
[nodeVec,nodeSpec,total,rootnode_number,rule_base,depth,consequent_degree,rule_weight_initial,length_of_rule] = rule_extraction_from_FBDT(node_final,0,0,nodeVec,nodeSpec,0,rule_base,depth,consequent_degree,number_of_data,label_index,label,rule_weight_initial,length_of_rule);
rule_weight=rule_weight_initial;
% % %Selection of s
data_rs=data_initial;
data_label=label_initial;
assocition_degree_for_data=association_degree_calculation(data_rs,rule_weight,rule_base,attribute_division,every_attribute_fuzzy_amount,fuzzy_division_points,[]);
s=[0.00001,0.0001,0.001,0.01,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9];
s_select=s(1)
s_acc=0
for i=1:size(s,2)
    [fitness,accuracy,interpretability]=func_fitness(ones(1,size(rule_base,1)),data_rs,data_label,label_index,rule_base,consequent_degree,fuzzy_division_points,data_max_value,data_min_value,length_of_rule,0.7,s(i),assocition_degree_for_data,rule_weight)
    if s_acc<fitness
        s_select=s(i);
        s_acc=fitness
    end
end
% Rule selection using improved genetic algorithms
[bestChromosome,best_rule_base,best_consequent,best_rule_weight,best_length_of_rule]=genetic_algorithm_rule_selection(assocition_degree_for_data,rule_base,0.8,data_rs,data_label,label_index,consequent_degree,rule_weight,fuzzy_division_points,data_max_value,data_min_value,length_of_rule,s_select,ro);
rule_base_size=size(best_rule_base,1);
rule_length_average=sum(best_length_of_rule)./rule_base_size;
%Calculation of test set correctness
%assocition_degree_for_test_data_0=association_degree_calculation(test_data,rule_weight,rule_base,attribute_division,every_attribute_fuzzy_amount,fuzzy_division_points,[]);
%test_accuracy_rate_0=classification_accuracy_rate(assocition_degree_for_test_data_0,label_index,test_data,fuzzy_division_points,test_label,data_max_value,data_min_value,rule_base,consequent_degree,s_select)  ;
assocition_degree_for_test_data=association_degree_calculation(test_data,best_rule_weight,best_rule_base,attribute_division,every_attribute_fuzzy_amount,fuzzy_division_points,[]);
test_accuracy_rate=classification_accuracy_rate(assocition_degree_for_test_data,label_index,test_data,fuzzy_division_points,test_label,data_max_value,data_min_value,best_rule_base,best_consequent,s_select)  ;
end
